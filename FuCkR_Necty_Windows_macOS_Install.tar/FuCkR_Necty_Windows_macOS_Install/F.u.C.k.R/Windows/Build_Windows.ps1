﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# Bygglogg i anvandarens profil; fungerar utan adminrattigheter.
$logDir = Join-Path $env:LOCALAPPDATA 'SMTPFieldTesterBuild\Logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$logFile = Join-Path $logDir ('Build_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt')
$transcriptStarted = $false
try {
    Start-Transcript -LiteralPath $logFile -Force -ErrorAction Stop | Out-Null
    $transcriptStarted = $true
    Write-Host "Bygglogg: $logFile" -ForegroundColor Cyan
} catch {
    Write-Warning "Kunde inte starta transkribering av byggloggen: $($_.Exception.Message)"
}

Push-Location -LiteralPath $PSScriptRoot
try {
    if (-not (Test-Path -LiteralPath '.\SMTP_Field_Tester.py' -PathType Leaf)) { throw 'SMTP_Field_Tester.py saknas i samma mapp som byggscriptet.' }
    if (-not (Test-Path -LiteralPath '.\FuCkR_icon.ico' -PathType Leaf)) { throw 'FuCkR_icon.ico saknas.' }
    if (-not (Test-Path -LiteralPath '.\FuCkR_icon.png' -PathType Leaf)) { throw 'FuCkR_icon.png saknas.' }
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Denna byggversion stoder Windows x64, inte 32-bitars Windows.' }
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { throw 'Detta byggscript ar avsett for Windows x64. Bygg for Windows ARM64 separat.' }

    $version = '3.14.10'
    $pythonDir = Join-Path $env:LOCALAPPDATA 'SMTPFieldTesterBuild\Python314'
    $pythonExe = Join-Path $pythonDir 'python.exe'
    $expectedHash = '92480239264744fe0386a1bd8275786fefa126e3129e56a68e22b52c73329965'
    $url = 'https://www.python.org/ftp/python/3.14.10/python-3.14.10-amd64.exe'

    $pythonReady = $false
    if (Test-Path -LiteralPath $pythonExe -PathType Leaf) {
        try {
            & $pythonExe -c 'import tkinter, venv, ensurepip, sys; assert (3, 14, 10) <= sys.version_info[:3] < (3, 15, 0)' *> $null
            $pythonReady = ($LASTEXITCODE -eq 0)
        } catch { $pythonReady = $false }
    }

    if (-not $pythonReady) {
        Write-Host "Python $version saknas i den isolerade byggmiljon. Hamtar officiell installerare..." -ForegroundColor Yellow
        $tempDir = Join-Path $env:TEMP ('SMTPFieldTester_' + [Guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
        $installer = Join-Path $tempDir 'python-installer.exe'
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $url -OutFile $installer -UseBasicParsing
            $actualHash = (Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($actualHash -ne $expectedHash) { throw "Python-installationens SHA256 stammer inte. Faktiskt: $actualHash" }
            $signature = Get-AuthenticodeSignature -FilePath $installer
            if ($signature.Status -ne 'Valid') { throw "Python-installationens Authenticode-signatur ar inte giltig: $($signature.Status)" }
            New-Item -ItemType Directory -Path $pythonDir -Force | Out-Null
            $arguments = @('/quiet', 'InstallAllUsers=0', ('TargetDir="{0}"' -f $pythonDir), 'Include_launcher=0', 'Include_pip=1', 'Include_tcltk=1', 'Include_test=0', 'PrependPath=0', 'Shortcuts=0')
            $proc = Start-Process -FilePath $installer -ArgumentList $arguments -Wait -PassThru
            if ($proc.ExitCode -notin @(0, 3010)) { throw "Python-installationen misslyckades. Exit code: $($proc.ExitCode)" }
            if ($proc.ExitCode -eq 3010) { Write-Warning 'Python-installationen rapporterade att en omstart kan behovas. Scriptet startar inte om datorn.' }
        } finally {
            Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) { throw "Python saknas efter installationen: $pythonExe" }
    & $pythonExe -c 'import tkinter, venv, ensurepip, sys; assert (3, 14, 10) <= sys.version_info[:3] < (3, 15, 0); print(sys.version)'
    if ($LASTEXITCODE -ne 0) { throw 'Python/Tkinter kunde inte verifieras.' }

    $venvDir = Join-Path $PSScriptRoot '.venv-windows'
    & $pythonExe -m venv $venvDir
    if ($LASTEXITCODE -ne 0) { throw 'Kunde inte skapa virtuell Python-miljo.' }
    $venvPython = Join-Path $venvDir 'Scripts\python.exe'
    & $venvPython -m pip install --disable-pip-version-check --upgrade 'pyinstaller>=6.22.3,<7'
    if ($LASTEXITCODE -ne 0) { throw 'Installation av PyInstaller misslyckades.' }
    & $venvPython -m py_compile '.\SMTP_Field_Tester.py'
    if ($LASTEXITCODE -ne 0) { throw 'Python-kallkoden klarade inte syntaxkontrollen.' }
    & $venvPython -m PyInstaller --noconfirm --clean --onefile --windowed --name FuCkR --icon '.\FuCkR_icon.ico' --add-data '.\FuCkR_icon.png;.' '.\SMTP_Field_Tester.py'
    if ($LASTEXITCODE -ne 0) { throw 'Paketering med PyInstaller misslyckades.' }

    $exe = Join-Path $PSScriptRoot 'dist\FuCkR.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw "Paketering rapporterade OK, men filen finns inte: $exe" }
    Write-Host "KLART MED BYGGET: $exe" -ForegroundColor Green
    Write-Host 'Nasta steg: automatisk installation till %LOCALAPPDATA%\Programs\FuCkR samt genvagar.' -ForegroundColor Green
} catch {
    Write-Host "BYGGFEL: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Se eventuell logg: $logFile" -ForegroundColor Yellow
    throw
} finally {
    Pop-Location
    if ($transcriptStarted) { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
}
