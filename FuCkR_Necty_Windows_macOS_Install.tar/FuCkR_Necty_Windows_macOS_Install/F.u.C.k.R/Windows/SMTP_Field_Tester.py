#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""F.u.C.k.R 1.4 – Windows och macOS. Kräver Python 3 med Tkinter.
Tester görs från datorns aktuella nät. Lösenord sparas aldrig till disk.
"""

import csv
import sys
import queue
import re
import smtplib
import socket
import ssl
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from email.message import EmailMessage
from email.utils import formatdate, make_msgid, parseaddr
from tkinter import Tk, StringVar, Text, END, PhotoImage, filedialog, messagebox, ttk
from tkinter import BOTH, LEFT, RIGHT, X, Y, HORIZONTAL, VERTICAL


APP_NAME = "F.u.C.k.R 1.4 | necty.se"
APP_EXPANSION = "Field Utility for Connectivity, Key Exchange & Relay"
SMTP2GO_PORTS = "2525:STARTTLS,587:STARTTLS,8025:STARTTLS,80:STARTTLS,25:STARTTLS,465:SSL,8465:SSL,443:SSL"
GENERAL_PORTS = "587:STARTTLS,465:SSL,25:STARTTLS,2525:STARTTLS"
PORT_RE = re.compile(r"^(\d{1,5})\s*:\s*(STARTTLS|SSL|PLAIN)$", re.IGNORECASE)


def parse_ports(text):
    """Retur [(port, mode)] – order och flera lägen på samma port tillåts."""
    entries = [item.strip() for item in re.split(r"[,;\n]+", text) if item.strip()]
    if not entries:
        raise ValueError("Ange minst en port, t.ex. 587:STARTTLS,465:SSL")
    if len(entries) > 40:
        raise ValueError("Max 40 port-/TLS-kombinationer per körning.")
    parsed = []
    for entry in entries:
        match = PORT_RE.fullmatch(entry)
        if not match:
            raise ValueError("Felaktigt portformat: %s (använd 587:STARTTLS,465:SSL,25:PLAIN)" % entry)
        port, mode = int(match.group(1)), match.group(2).upper()
        if port < 1 or port > 65535:
            raise ValueError("Port utanför intervallet 1–65535: %s" % port)
        if (port, mode) not in parsed:
            parsed.append((port, mode))
    return parsed


def valid_email(value):
    """Enkel fältkontroll; SMTP-servern avgör slutlig giltighet."""
    if not value or any(char in value for char in "\r\n\x00"):
        return False
    name, address = parseaddr(value)
    return not name and address == value and "@" in address and not any(c.isspace() for c in address)


def describe_error(exc, password=""):
    if isinstance(exc, smtplib.SMTPResponseException):
        detail = exc.smtp_error
        if isinstance(detail, bytes):
            detail = detail.decode("utf-8", "replace")
        msg = "SMTP %s: %s" % (exc.smtp_code, detail)
    elif isinstance(exc, ssl.SSLCertVerificationError):
        msg = "Certifikatverifiering misslyckades: %s" % exc
    elif isinstance(exc, socket.gaierror):
        msg = "DNS: %s" % exc
    elif isinstance(exc, (socket.timeout, TimeoutError)):
        msg = "Timeout: ingen respons inom tidsgränsen"
    else:
        msg = "%s: %s" % (type(exc).__name__, exc)
    if password:
        msg = msg.replace(password, "[DOLT LÖSENORD]")
    return " ".join(str(msg).split())[:350]


def establish_smtp(host, port, mode, timeout, stage_callback=None):
    """Ger en ansluten SMTP-session; callback visar var ev. fel uppstår."""
    def stage(name):
        if stage_callback is not None:
            stage_callback(name)

    context = ssl.create_default_context()
    stage("TLS" if mode == "SSL" else "SMTP")
    if mode == "SSL":
        server = smtplib.SMTP_SSL(host, port, timeout=timeout, context=context)
    else:
        server = smtplib.SMTP(host, port, timeout=timeout)
    try:
        stage("SMTP")
        code, response = server.ehlo()
        if code != 250:
            raise smtplib.SMTPHeloError(code, response)
        if mode == "STARTTLS":
            stage("TLS")
            if not server.has_extn("starttls"):
                raise smtplib.SMTPNotSupportedError("Servern annonserar inte STARTTLS")
            server.starttls(context=context)
            stage("SMTP")
            code, response = server.ehlo()  # EHLO måste upprepas efter STARTTLS.
            if code != 250:
                raise smtplib.SMTPHeloError(code, response)
        return server
    except Exception:
        server.close()
        raise


def probe(host, port, mode, username, password, timeout=6, auth_guard=None, auth_rejected=None):
    started = time.perf_counter()
    result = {
        "port": port, "mode": mode, "tcp": "–", "smtp": "–",
        "tls": "–", "auth": "–", "status": "FEL", "info": "",
        "local_ip": "", "remote_ip": "", "tls_version": "", "seconds": "",
    }
    stage = ["TCP"]
    try:
        # Separat TCP-probe: ett TLS-fel ska inte felaktigt kallas ISP-portblock.
        with socket.create_connection((host, port), timeout=timeout) as sock:
            result["tcp"] = "OK"
            result["local_ip"] = sock.getsockname()[0]
            result["remote_ip"] = sock.getpeername()[0]

        with establish_smtp(host, port, mode, timeout, lambda s: stage.__setitem__(0, s)) as server:
            result["smtp"] = "OK"
            if mode in ("SSL", "STARTTLS"):
                ssl_socket = server.sock
                result["tls"] = "OK"
                if hasattr(ssl_socket, "version"):
                    result["tls_version"] = ssl_socket.version() or ""
                stage[0] = "AUTH"
                if username:
                    # Ett nekat lösenord får inte orsaka flera samtidiga AUTH-försök.
                    # Samma lås delas mellan alla portar under en testkörning.
                    if auth_guard is not None and auth_rejected is not None:
                        with auth_guard:
                            if auth_rejected.is_set():
                                result["auth"] = "Hoppad"
                                result["status"] = "TLS OK, AUTH hoppad"
                                result["info"] = "AUTH nekades på en annan port. Fler försök stoppade för att minska risk för kontolåsning"
                            else:
                                try:
                                    server.login(username, password)
                                except smtplib.SMTPAuthenticationError:
                                    auth_rejected.set()
                                    raise
                                result["auth"] = "OK"
                                result["status"] = "OK"
                                result["info"] = "SMTP-inloggning lyckades"
                    else:
                        server.login(username, password)
                        result["auth"] = "OK"
                        result["status"] = "OK"
                        result["info"] = "SMTP-inloggning lyckades"
                else:
                    result["auth"] = "Ej testad"
                    result["status"] = "OK utan AUTH"
                    result["info"] = "SMTP och TLS fungerar; inga kontouppgifter angivna"
            else:
                result["tls"] = "Nej"
                result["auth"] = "Ej testad"
                result["status"] = "OK okrypterat"
                result["info"] = "Endast SMTP/EHLO. Lösenord skickas aldrig okrypterat"
    except Exception as exc:
        if stage[0] == "TLS":
            result["tls"] = "FEL"
        elif stage[0] == "AUTH":
            result["auth"] = "FEL"
        elif stage[0] == "SMTP":
            result["smtp"] = "FEL"
        result["info"] = describe_error(exc, password)
    finally:
        result["seconds"] = "%.2f" % (time.perf_counter() - started)
    return result


def send_mail(host, port, mode, username, password, sender, recipient, customer, timeout=10):
    if mode == "PLAIN":
        raise ValueError("Testmail kräver SSL eller STARTTLS; okrypterad sändning är avstängd.")
    message = EmailMessage()
    message["From"] = sender
    message["To"] = recipient
    message["Subject"] = "F.u.C.k.R - SMTP-test %s" % datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    message["Date"] = formatdate(localtime=True)
    message["Message-ID"] = make_msgid()
    message.set_content(
        "Testmail från F.u.C.k.R / necty.se.\n"
        "Kund: %s\nSMTP-server: %s\nPort: %s\nKryptering: %s\n"
        "SMTP-serverns acceptans garanterar inte leverans till inkorgen.\n"
        % (customer or "Ej angiven", host, port, mode)
    )
    with establish_smtp(host, port, mode, timeout) as server:
        if username:
            server.login(username, password)
        refused = server.send_message(message)
        if refused:
            raise smtplib.SMTPRecipientsRefused(refused)
    return "SMTP-servern accepterade testmeddelandet till %s. Slutlig leverans är INTE verifierad." % recipient


class SMTPFieldTester:
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.geometry("1180x810")
        root.minsize(960, 690)
        self.icon_image = None
        try:
            from pathlib import Path
            base_dir = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
            icon_file = base_dir / "FuCkR_icon.png"
            if icon_file.is_file():
                self.icon_image = PhotoImage(file=str(icon_file))
                root.iconphoto(True, self.icon_image)
        except Exception:
            pass  # Ikonen är dekorativ. Appens tester ska fungera ändå.
        self.events = queue.Queue()
        self.results = {}
        self.host_tested = ""
        self.customer_tested = ""
        self.timestamp = ""
        self.busy = False
        self.provider = StringVar(value="SMTP2GO")
        self.host = StringVar(value="mail.smtp2go.com")
        self.customer = StringVar()
        self.username = StringVar()
        self.password = StringVar()
        self.sender = StringVar()
        self.recipient = StringVar()
        self.timeout = StringVar(value="6")
        self.status = StringVar(value="Redo. Testa från samma nät/VLAN som kopiatorn.")
        self.create_ui()
        self.root.after(150, self.poll_events)

    def create_ui(self):
        panel = ttk.Frame(self.root, padding=14)
        panel.pack(fill=BOTH, expand=True)
        panel.columnconfigure(1, weight=1)
        panel.columnconfigure(3, weight=1)

        brand = ttk.Frame(panel)
        brand.grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 14))
        ttk.Label(brand, text="F.u.C.k.R", font=("TkDefaultFont", 28, "bold"), foreground="#144662").pack(anchor="w")
        ttk.Label(brand, text=APP_EXPANSION, font=("TkDefaultFont", 11, "bold")).pack(anchor="w", pady=(0, 3))
        ttk.Label(brand, text="SMTP Field Tester  •  utvecklad för necty.se", foreground="#567079").pack(anchor="w")
        ttk.Label(panel, text="Leverantör").grid(row=1, column=0, sticky="w", pady=4)
        provider = ttk.Combobox(panel, textvariable=self.provider, values=["SMTP2GO", "Ymer", "Annan"], state="readonly")
        provider.grid(row=1, column=1, sticky="ew", padx=(8, 14))
        provider.bind("<<ComboboxSelected>>", self.change_provider)
        ttk.Label(panel, text="Kund/plats").grid(row=1, column=2, sticky="w")
        ttk.Entry(panel, textvariable=self.customer).grid(row=1, column=3, sticky="ew", padx=(8, 0))

        ttk.Label(panel, text="SMTP-server").grid(row=2, column=0, sticky="w", pady=4)
        ttk.Entry(panel, textvariable=self.host).grid(row=2, column=1, sticky="ew", padx=(8, 14))
        ttk.Label(panel, text="Timeout (sek)").grid(row=2, column=2, sticky="w")
        ttk.Combobox(panel, textvariable=self.timeout, state="readonly", values=["4", "6", "10", "15"], width=6).grid(row=2, column=3, sticky="w", padx=(8, 0))

        ttk.Label(panel, text="Porter / TLS-lägen").grid(row=3, column=0, sticky="nw", pady=4)
        self.ports = Text(panel, height=3, wrap="word")
        self.ports.grid(row=3, column=1, columnspan=3, sticky="ew", padx=(8, 0), pady=4)
        self.ports.insert("1.0", SMTP2GO_PORTS)
        ttk.Label(panel, text="Format: 587:STARTTLS,465:SSL,25:PLAIN. Ymers portar är inte verifierade – redigera listan.", foreground="#666666").grid(row=4, column=0, columnspan=4, sticky="w", pady=(0, 8))

        ttk.Label(panel, text="SMTP-användare").grid(row=5, column=0, sticky="w", pady=4)
        ttk.Entry(panel, textvariable=self.username).grid(row=5, column=1, sticky="ew", padx=(8, 14))
        ttk.Label(panel, text="SMTP-lösenord").grid(row=5, column=2, sticky="w")
        ttk.Entry(panel, textvariable=self.password, show="•").grid(row=5, column=3, sticky="ew", padx=(8, 0))

        ttk.Label(panel, text="Avsändaradress").grid(row=6, column=0, sticky="w", pady=4)
        ttk.Entry(panel, textvariable=self.sender).grid(row=6, column=1, sticky="ew", padx=(8, 14))
        ttk.Label(panel, text="Mottagare testmail").grid(row=6, column=2, sticky="w")
        ttk.Entry(panel, textvariable=self.recipient).grid(row=6, column=3, sticky="ew", padx=(8, 0))

        actions = ttk.Frame(panel)
        actions.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(9, 13))
        self.test_button = ttk.Button(actions, text="Testa alla portkombinationer", command=self.start_test)
        self.test_button.pack(side=LEFT, padx=(0, 9))
        self.mail_button = ttk.Button(actions, text="Skicka ETT testmail (vald rad)", command=self.start_mail, state="disabled")
        self.mail_button.pack(side=LEFT, padx=(0, 9))
        self.export_button = ttk.Button(actions, text="Exportera CSV", command=self.export_csv, state="disabled")
        self.export_button.pack(side=LEFT)
        ttk.Button(actions, text="Visa programmapp", command=self.show_app_location).pack(side=RIGHT, padx=(12, 0))

        table_area = ttk.Frame(panel)
        table_area.grid(row=8, column=0, columnspan=4, sticky="nsew")
        panel.rowconfigure(8, weight=1)
        table_area.rowconfigure(0, weight=1)
        table_area.columnconfigure(0, weight=1)
        columns = ("port", "mode", "tcp", "smtp", "tls", "auth", "version", "result", "info")
        self.table = ttk.Treeview(table_area, columns=columns, show="headings", selectmode="browse", height=12)
        labels = {
            "port": "Port", "mode": "Kryptering", "tcp": "TCP", "smtp": "SMTP",
            "tls": "TLS", "auth": "AUTH", "version": "TLS-version",
            "result": "Resultat", "info": "Fel / information",
        }
        widths = {"port": 65, "mode": 105, "tcp": 60, "smtp": 60, "tls": 58, "auth": 90, "version": 100, "result": 115, "info": 400}
        for key in columns:
            self.table.heading(key, text=labels[key])
            self.table.column(key, width=widths[key], minwidth=50, stretch=key == "info")
        self.table.tag_configure("ok", background="#e9f7e9")
        self.table.tag_configure("fail", background="#fbeaea")
        self.table.tag_configure("partial", background="#fff4d7")
        self.table.grid(row=0, column=0, sticky="nsew")
        scrollbar_v = ttk.Scrollbar(table_area, orient=VERTICAL, command=self.table.yview)
        scrollbar_v.grid(row=0, column=1, sticky="ns")
        scrollbar_h = ttk.Scrollbar(table_area, orient=HORIZONTAL, command=self.table.xview)
        scrollbar_h.grid(row=1, column=0, sticky="ew")
        self.table.configure(yscrollcommand=scrollbar_v.set, xscrollcommand=scrollbar_h.set)
        self.table.bind("<<TreeviewSelect>>", lambda event: self.update_buttons())

        ttk.Label(panel, textvariable=self.status, wraplength=1060).grid(row=9, column=0, columnspan=4, sticky="w", pady=(10, 5))
        ttk.Label(panel, text="Grönt = säker SMTP med/utan verifierad AUTH. Gult = okrypterat eller AUTH hoppad. Rött = fel. Ett accepterat mail garanterar inte leverans.", foreground="#666666", wraplength=1070).grid(row=10, column=0, columnspan=4, sticky="w")

    def show_app_location(self):
        """Visa den faktiska filplatsen för appen eller källkoden."""
        from pathlib import Path
        path = Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve()
        if sys.platform == "darwin":
            for parent in path.parents:
                if parent.suffix.lower() == ".app":
                    path = parent
                    break
        messagebox.showinfo("F.u.C.k.R - programplats", "Programmet finns här:\n\n" + str(path))

    def change_provider(self, event=None):
        if self.busy:
            return
        if self.provider.get() == "SMTP2GO":
            self.host.set("mail.smtp2go.com")
            value = SMTP2GO_PORTS
        else:
            self.host.set("")
            value = GENERAL_PORTS
        self.ports.delete("1.0", END)
        self.ports.insert("1.0", value)
        self.results.clear()
        for item in self.table.get_children():
            self.table.delete(item)
        self.update_buttons()

    def get_settings(self):
        host = self.host.get().strip()
        if not host or any(c.isspace() for c in host) or "://" in host or "/" in host:
            raise ValueError("Ange ett SMTP-servernamn eller en IP-adress (inte en URL).")
        username = self.username.get().strip()
        password = self.password.get()
        if bool(username) != bool(password):
            raise ValueError("Ange både SMTP-användare och lösenord, eller lämna båda tomma.")
        return host, username, password, int(self.timeout.get())

    def start_test(self):
        if self.busy:
            return
        try:
            host, username, password, timeout = self.get_settings()
            ports = parse_ports(self.ports.get("1.0", END))
        except ValueError as exc:
            messagebox.showerror("Kontrollera inställningarna", str(exc))
            return
        self.busy = True
        self.results = {}
        self.host_tested = host
        self.customer_tested = self.customer.get().strip()
        self.timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
        for item in self.table.get_children():
            self.table.delete(item)
        for i, (port, mode) in enumerate(ports):
            self.table.insert("", END, iid=str(i), values=(port, mode, "–", "–", "–", "–", "–", "Väntar", ""))
        self.status.set("Testar %s mot %s (%s kombinationer)..." % (self.provider.get(), host, len(ports)))
        self.update_buttons()
        threading.Thread(target=self.test_worker, args=(host, ports, username, password, timeout), daemon=True).start()

    def test_worker(self, host, ports, username, password, timeout):
        try:
            guard, rejected = threading.Lock(), threading.Event()
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = {
                    executor.submit(probe, host, port, mode, username, password, timeout, guard, rejected): i
                    for i, (port, mode) in enumerate(ports)
                }
                for future in as_completed(futures):
                    i = futures[future]
                    try:
                        result = future.result()
                    except Exception as exc:
                        port, mode = ports[i]
                        result = {"port": port, "mode": mode, "tcp": "–", "smtp": "–", "tls": "–", "auth": "–", "status": "FEL", "info": describe_error(exc, password), "local_ip": "", "remote_ip": "", "tls_version": "", "seconds": ""}
                    self.events.put(("probe", i, result))
        finally:
            self.events.put(("finished",))

    def start_mail(self):
        if self.busy:
            return
        selected = self.table.selection()
        if len(selected) != 1:
            messagebox.showinfo("Välj rad", "Markera en rad med fungerande TLS.")
            return
        result = self.results.get(int(selected[0]))
        if not result or result["tls"] != "OK" or result["status"] not in ("OK", "OK utan AUTH"):
            messagebox.showerror("Ej redo", "Välj en rad där TLS fungerar och eventuell AUTH lyckats.")
            return
        try:
            host, username, password, timeout = self.get_settings()
            if host != self.host_tested:
                raise ValueError("SMTP-servern har ändrats. Gör ett nytt porttest först.")
            sender, recipient = self.sender.get().strip(), self.recipient.get().strip()
            if not valid_email(sender) or not valid_email(recipient):
                raise ValueError("Ange en giltig avsändaradress och mottagaradress.")
        except ValueError as exc:
            messagebox.showerror("Kontrollera inställningarna", str(exc))
            return
        if not messagebox.askyesno("Bekräfta testmail", "Skicka exakt ETT SMTP-testmail via %s:%s (%s) till %s?" % (host, result["port"], result["mode"], recipient)):
            return
        self.busy = True
        self.update_buttons()
        self.status.set("Skickar testmail till %s..." % recipient)
        threading.Thread(target=self.mail_worker, args=(host, result["port"], result["mode"], username, password, sender, recipient, self.customer.get().strip(), timeout), daemon=True).start()

    def mail_worker(self, host, port, mode, username, password, sender, recipient, customer, timeout):
        try:
            msg = send_mail(host, port, mode, username, password, sender, recipient, customer, max(timeout, 10))
            self.events.put(("mail", True, msg))
        except Exception as exc:
            self.events.put(("mail", False, describe_error(exc, password)))

    def poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "probe":
                    _, i, result = event
                    self.results[i] = result
                    tag = "ok" if result["status"] in ("OK", "OK utan AUTH") else "partial" if result["status"] in ("OK okrypterat", "TLS OK, AUTH hoppad") else "fail"
                    values = (result["port"], result["mode"], result["tcp"], result["smtp"], result["tls"], result["auth"], result["tls_version"] or "–", result["status"], result["info"])
                    self.table.item(str(i), values=values, tags=(tag,))
                    self.status.set("Klara: %s av %s; TLS/SMTP OK: %s" % (len(self.results), len(self.table.get_children()), sum(r["status"] in ("OK", "OK utan AUTH") for r in self.results.values())))
                elif event[0] == "finished":
                    self.busy = False
                    good = [(r["port"], r["mode"]) for r in self.results.values() if r["status"] in ("OK", "OK utan AUTH")]
                    if good:
                        self.status.set("KLART. Fungerande säkra alternativ: " + ", ".join("%s/%s" % pair for pair in sorted(good)))
                    else:
                        self.status.set("KLART. Ingen verifierad säker SMTP-konfiguration. Se respektive rad för DNS/TCP/SMTP/TLS/AUTH-fel.")
                    self.update_buttons()
                elif event[0] == "mail":
                    self.busy = False
                    self.status.set(event[2])
                    self.update_buttons()
                    if event[1]:
                        messagebox.showinfo("SMTP accepterade testmail", event[2])
                    else:
                        messagebox.showerror("Testmail misslyckades", event[2])
        except queue.Empty:
            pass
        self.root.after(150, self.poll_events)

    def update_buttons(self):
        self.test_button.configure(state="disabled" if self.busy else "normal")
        self.export_button.configure(state="normal" if self.results and not self.busy else "disabled")
        selected = self.table.selection()
        row = self.results.get(int(selected[0])) if selected else None
        mail_ready = bool(row and row["tls"] == "OK" and row["status"] in ("OK", "OK utan AUTH"))
        self.mail_button.configure(state="normal" if mail_ready and not self.busy else "disabled")

    def export_csv(self):
        if not self.results:
            return
        filename = "FuCkR_SMTP_%s.csv" % datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(title="Exportera SMTP-resultat", defaultextension=".csv", initialfile=filename, filetypes=[("CSV", "*.csv")])
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8-sig", newline="") as stream:
                writer = csv.writer(stream, delimiter=";")
                writer.writerow(["Tid", "Kund", "Server", "Port", "Kryptering", "TCP", "SMTP", "TLS", "TLS-version", "AUTH", "Resultat", "Lokal IP", "Server-IP", "Tid sek", "Detalj"])
                for index in sorted(self.results):
                    r = self.results[index]
                    writer.writerow([self.timestamp, self.customer_tested, self.host_tested, r["port"], r["mode"], r["tcp"], r["smtp"], r["tls"], r["tls_version"], r["auth"], r["status"], r["local_ip"], r["remote_ip"], r["seconds"], r["info"]])
        except OSError as exc:
            messagebox.showerror("Exportfel", str(exc))
            return
        self.status.set("CSV sparad: " + path + " (utan lösenord)")
        messagebox.showinfo("Export klart", "Rapport sparad:\n" + path)


def main():
    root = Tk()
    ttk.Style(root)  # Använd operativsystemets ttk-tema.
    SMTPFieldTester(root)
    root.mainloop()


if __name__ == "__main__":
    main()
