@echo off
setlocal EnableExtensions DisableDelayedExpansion
title F.u.C.k.R - necty.se

rem F.u.C.k.R v1.4 - install.bat: build if missing, install, create shortcuts, launch.
rem Do not launch from the ZIP temp directory. Install into LOCALAPPDATA\Programs\FuCkR.
pushd "%~dp0" >nul 2>&1
if errorlevel 1 goto folder_failed

set "PS_EXE="
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS_EXE=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not defined PS_EXE if exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not defined PS_EXE if exist "%SystemRoot%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe" set "PS_EXE=%SystemRoot%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
if not defined PS_EXE if defined ProgramW6432 if exist "%ProgramW6432%\PowerShell\7\pwsh.exe" set "PS_EXE=%ProgramW6432%\PowerShell\7\pwsh.exe"
if not defined PS_EXE if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" set "PS_EXE=%ProgramFiles%\PowerShell\7\pwsh.exe"
if not defined PS_EXE goto powershell_missing

if exist "dist\FuCkR.exe" goto install

echo ========================================================
echo   F.u.C.k.R - FORSTA STARTEN - necty.se
echo ========================================================
echo.
echo Bygger appen lokalt. Python och PyInstaller hamtas vid behov.
echo Inga kommandon eller administratorrattigheter kravs pa Windows.
echo Internet kravs for forsta bygget.
echo.
"%PS_EXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build_Windows.ps1"
if errorlevel 1 goto build_failed
if not exist "dist\FuCkR.exe" goto missing_file

:install
echo.
echo Installerar F.u.C.k.R och skapar genvagar...
"%PS_EXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install_Windows.ps1"
if errorlevel 1 goto install_failed
set "INSTALLED=%LOCALAPPDATA%\Programs\FuCkR\FuCkR.exe"
if not exist "%INSTALLED%" goto missing_file
echo.
echo Startar F.u.C.k.R fran:
echo %INSTALLED%
start "" "%INSTALLED%"
if errorlevel 1 goto start_failed
popd
exit /b 0

:powershell_missing
echo FEL: Windows PowerShell hittades inte pa systemets standardplatser.
goto failed
:build_failed
echo FEL: Bygget misslyckades. Se texten ovan och loggar i:
echo %LOCALAPPDATA%\SMTPFieldTesterBuild\Logs
goto failed
:install_failed
echo FEL: Installationen eller genvagarna kunde inte skapas.
goto failed
:missing_file
echo FEL: FuCkR.exe kunde inte hittas efter bygget/installationen.
goto failed
:start_failed
echo FEL: Windows kunde inte starta FuCkR.exe.
goto failed
:folder_failed
echo FEL: Kunde inte oppna projektmappen. Packa upp hela ZIP-filen.
goto failed_no_pop
:failed
echo.
echo Skicka hela felmeddelandet fran detta fonster om problemet kvarstar.
pause
popd
exit /b 1
:failed_no_pop
pause
exit /b 1
