﻿$ErrorActionPreference = 'Stop'

# Per-user installation - no administrator privileges and no changes to PATH.
$sourceExe = Join-Path $PSScriptRoot 'dist\FuCkR.exe'
if (-not (Test-Path -LiteralPath $sourceExe -PathType Leaf)) { throw "Den byggda appen saknas: $sourceExe" }
if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { throw 'LOCALAPPDATA saknas i anvandarsessionen.' }

$installDir = Join-Path $env:LOCALAPPDATA 'Programs\FuCkR'
$installedExe = Join-Path $installDir 'FuCkR.exe'
New-Item -ItemType Directory -Path $installDir -Force | Out-Null
try {
    Copy-Item -LiteralPath $sourceExe -Destination $installedExe -Force -ErrorAction Stop
} catch {
    throw "Kan inte uppdatera $installedExe. Stang F.u.C.k.R om det redan ar igang. Detalj: $($_.Exception.Message)"
}

if (-not (Test-Path -LiteralPath $installedExe -PathType Leaf)) { throw "Installationsfilen saknas efter kopiering: $installedExe" }
$programs = [Environment]::GetFolderPath('Programs')
if ([string]::IsNullOrWhiteSpace($programs)) { $programs = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs' }
if ([string]::IsNullOrWhiteSpace($programs)) { throw 'Kunde inte hitta anvandarens startmeny.' }
$menuDir = Join-Path $programs 'Necty.se'
New-Item -ItemType Directory -Path $menuDir -Force | Out-Null

$wshShell = New-Object -ComObject WScript.Shell
function Set-FuCkRShortcut {
    param([Parameter(Mandatory=$true)][string]$ShortcutPath)
    $shortcut = $wshShell.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = $installedExe
    $shortcut.WorkingDirectory = $installDir
    $shortcut.Description = 'F.u.C.k.R - SMTP- och natverksdiagnostik for Necty.se'
    $shortcut.IconLocation = "$installedExe,0"
    $shortcut.Save()
    if (-not (Test-Path -LiteralPath $ShortcutPath -PathType Leaf)) { throw "Genvagen kunde inte skapas: $ShortcutPath" }
}

$menuShortcut = Join-Path $menuDir 'F.u.C.k.R.lnk'
Set-FuCkRShortcut -ShortcutPath $menuShortcut
Write-Host "STARTMENY: $menuShortcut" -ForegroundColor Green

try {
    # WScript.Shell.SpecialFolders("Desktop") honors redirected and OneDrive desktops.
    $desktop = [string]$wshShell.SpecialFolders.Item('Desktop')
    if ([string]::IsNullOrWhiteSpace($desktop) -or -not (Test-Path -LiteralPath $desktop -PathType Container)) {
        throw 'Windows kunde inte identifiera anvandarens riktiga skrivbordskatalog.'
    }
    $desktopShortcut = Join-Path $desktop 'F.u.C.k.R.lnk'
    Set-FuCkRShortcut -ShortcutPath $desktopShortcut
    Write-Host "SKRIVBORD: $desktopShortcut" -ForegroundColor Green
} catch {
    # Start-menu shortcut remains usable, so desktop errors are nonfatal.
    Write-Warning "Skrivbordsgenvagen kunde inte skapas: $($_.Exception.Message)"
}

Write-Host "INSTALLERAD APP: $installedExe" -ForegroundColor Cyan
Write-Host 'F.u.C.k.R ar nu installerad for den inloggade anvandaren.' -ForegroundColor Green
