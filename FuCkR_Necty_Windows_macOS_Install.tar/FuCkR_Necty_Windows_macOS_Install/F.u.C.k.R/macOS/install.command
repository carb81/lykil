#!/bin/bash
# F.u.C.k.R v1.4 - install.command: dubbelklick i Finder. Installerar i ~/Applications.
set -uo pipefail

cd "$(dirname "$0")" || exit 1
APP="$(pwd)/dist/F.u.C.k.R.app"
INSTALL_DIR="$HOME/Applications"
INSTALLED_APP="$INSTALL_DIR/F.u.C.k.R.app"

show_error() {
    printf '\nFEL: %s\n' "$1" >&2
    printf 'Tryck Enter för att stänga detta fönster... '
    read -r _ || true
    exit 1
}

if [[ "$(uname -s)" != "Darwin" ]]; then
    show_error 'Detta startprogram fungerar endast på macOS.'
fi

if [[ ! -d "$APP" ]]; then
    printf '%s\n' '===================================================' ' F.u.C.k.R - FÖRSTA STARTEN - necty.se' '===================================================' ''
    echo 'Python och PyInstaller hämtas vid behov; internet behövs första gången.'
    echo 'Mac kan begära administratörslösenord om Python saknas.'
    echo ''
    bash ./Build_macOS.sh || show_error 'Mac-bygget misslyckades. Läs felmeddelandet ovan.'
fi
[[ -d "$APP" ]] || show_error "Den byggda appen saknas: $APP"

mkdir -p "$INSTALL_DIR" || show_error "Kunde inte skapa: $INSTALL_DIR"
# ditto bevarar macOS-appens resursfiler och exekveringsrättigheter.
/usr/bin/ditto "$APP" "$INSTALLED_APP" || show_error 'Kunde inte kopiera appen till ~/Applications.'
[[ -d "$INSTALLED_APP" ]] || show_error "Installerad app kunde inte hittas: $INSTALLED_APP"
printf 'INSTALLERAD APP: %s\n' "$INSTALLED_APP"
echo 'Appen finns nu i din Applications-mapp och kan öppnas via Finder.'
/usr/bin/open "$INSTALLED_APP" || show_error 'Kunde inte öppna appen. Kontrollera Gatekeeper och signering.'
exit 0
