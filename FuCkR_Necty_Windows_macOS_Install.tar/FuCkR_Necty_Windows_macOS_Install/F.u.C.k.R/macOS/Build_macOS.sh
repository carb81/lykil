#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"
[[ -f SMTP_Field_Tester.py && -f FuCkR_icon.png && -f FuCkR_icon.icns ]] || { echo 'FEL: SMTP_Field_Tester.py saknas i projektmappen.' >&2; exit 1; }
[[ "$(uname -s)" == 'Darwin' ]] || { echo 'FEL: Mac-appen maste byggas pa macOS.' >&2; exit 1; }

PYTHON='/Library/Frameworks/Python.framework/Versions/3.14/bin/python3.14'
PYTHON_VERSION='3.14.10'
PYTHON_URL='https://www.python.org/ftp/python/3.14.10/python-3.14.10-macos11.pkg'
PYTHON_SHA256='286c7018aa2730f6747ca433dccdc2b31be45f078a9ea0ffa44d5f06368fd2d7'

python_ready() {
    [[ -x "$PYTHON" ]] && "$PYTHON" -c 'import tkinter, venv, ensurepip, sys; assert (3, 14, 10) <= sys.version_info[:3] < (3, 15, 0)' >/dev/null 2>&1
}

if ! python_ready; then
    echo "Python ${PYTHON_VERSION} med Tkinter saknas. Laddar ner officiellt macOS-paket från python.org..."
    TMP_DIR="$(mktemp -d)"
    trap 'rm -rf "$TMP_DIR"' EXIT
    PKG="$TMP_DIR/python-${PYTHON_VERSION}.pkg"
    curl --fail --location --retry 3 --connect-timeout 20 --output "$PKG" "$PYTHON_URL"
    ACTUAL_SHA256="$(shasum -a 256 "$PKG" | awk '{print $1}')"
    if [[ "$ACTUAL_SHA256" != "$PYTHON_SHA256" ]]; then
        echo "FEL: SHA256 stammer inte. Nedladdad fil: $ACTUAL_SHA256" >&2
        exit 1
    fi
    echo 'SHA256 OK. Installerar Python for alla lokala anvandare (sudo kommer att fraga efter administratorslosenord).'
    sudo /usr/sbin/installer -pkg "$PKG" -target /
    python_ready || { echo "FEL: Python/Tkinter saknas efter installationen: $PYTHON" >&2; exit 1; }
    rm -rf "$TMP_DIR"
    trap - EXIT
fi

"$PYTHON" -c 'import tkinter, sys; print("Python:", sys.version); print("Tkinter OK")'
"$PYTHON" -m venv .venv-macos
VENV_PYTHON="$(pwd)/.venv-macos/bin/python"
"$VENV_PYTHON" -m pip install --disable-pip-version-check --upgrade 'pyinstaller>=6.22.3,<7'
"$VENV_PYTHON" -m py_compile SMTP_Field_Tester.py
"$VENV_PYTHON" -m PyInstaller --noconfirm --clean --onedir --windowed --target-arch universal2 --name F.u.C.k.R --icon FuCkR_icon.icns --add-data "FuCkR_icon.png:." SMTP_Field_Tester.py

APP="$(pwd)/dist/F.u.C.k.R.app"
[[ -d "$APP" ]] || { echo "FEL: Appfilen skapades inte: $APP" >&2; exit 1; }
echo "KLART: $APP"
echo 'Appen har en medpackad Pythonmiljo. Teknikerns Mac behover inte ha Python installerat.'
echo 'For distribution till andra Mac-datorer kan Developer ID-signering och notarization behovas.'
